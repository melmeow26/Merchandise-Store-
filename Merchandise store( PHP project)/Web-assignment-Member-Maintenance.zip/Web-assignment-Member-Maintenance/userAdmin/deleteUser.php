<?php
include '../_base.php';

// ----------------------------------------------------------------------------

if (is_post()) {
    $id = req('id');

    // Delete photo if it exists
    $stm = $_db->prepare('SELECT photo FROM user WHERE id = ?');
    $stm->execute([$id]);
    $photo = $stm->fetchColumn();

    if ($photo && file_exists("../photos/$photo")) {
        unlink("../photos/$photo");
    }

    // Delete related items
    $stm = $_db->prepare('DELETE FROM `item` WHERE order_id IN (SELECT id FROM `order` WHERE user_id = ?)');
    $stm->execute([$id]);

    // Delete related orders
    $stm = $_db->prepare('DELETE FROM `order` WHERE user_id = ?');
    $stm->execute([$id]);

    // Delete the user
    $stm = $_db->prepare('DELETE FROM user WHERE id = ?');
    $stm->execute([$id]);

    temp('info', 'Record deleted');
}

redirect('/../Userlist.php');

// ----------------------------------------------------------------------------
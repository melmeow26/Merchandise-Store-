<?php
require '../_base.php';

// Get the user ID from the query string
$id = req('id');

// Fetch user details from the database
$stm = $_db->prepare('SELECT * FROM user WHERE id = ?');
$stm->execute([$id]);
$user = $stm->fetch(PDO::FETCH_OBJ);

if (!$user) {
    die('User not found.');
}

$_title = 'User Details';
include '../_head.php';
?>

<style>
    .user-details {
        display: flex;
        flex-direction: column;
        align-items: center; /* Center horizontally */
        justify-content: center; /* Center vertically (optional) */
        text-align: center; /* Center text inside the container */
        margin: 20px auto; /* Add spacing and center the container */
        max-width: 400px; /* Optional: Limit the width of the container */
    }
</style>

<h1 class="page-title"><?= htmlspecialchars($user->name) ?></h1>

<div class="user-details">
    <img src="/../photos/<?= htmlspecialchars($user->photo) ?>" alt="<?= htmlspecialchars($user->name) ?>" class="user-image">
    <p><strong>Email:</strong> <?= htmlspecialchars($user->email) ?></p>
    <p><strong>Phone Number:</strong> <?= htmlspecialchars($user->phone_number) ?></p>
    <p><strong>Address:</strong> <?= htmlspecialchars($user->address) ?></p>
    <p><strong>Role:</strong> <?= htmlspecialchars($user->role) ?></p>
</div>

<p>
    <button onclick="history.back()">⬅️ Back</button>
</p>

<?php
include '../_foot.php';
<?php
include '../_base.php';

// ----------------------------------------------------------------------------

if (is_get()) {
    $id = req('id');

    $stm = $_db->prepare('SELECT * FROM user WHERE id = ?');
    $stm->execute([$id]);
    $u = $stm->fetch();

    if (!$u) {
        redirect('/../Userlist.php');
    }

    extract((array)$u);
    $_SESSION['photo'] = $u->photo;
}

if (is_post()) {
    $id = req('id');
    $email = req('email');
    $name  = req('name');
    $phone_number = req('phone_number');
    $address = req('address');
    $role = req('role');
    $photo = $_SESSION['photo'];
    $f = get_file('photo');

    // Check for duplicate email
    $stm = $_db->prepare('SELECT COUNT(*) FROM user WHERE email = ? AND id != ?');
    $stm->execute([$email, $id]);
    if ($stm->fetchColumn() > 0) {
        $_err['email'] = 'Email address already exists';
    }

    // Check for duplicate phone number
    $stm = $_db->prepare('SELECT COUNT(*) FROM user WHERE phone_number = ? AND id != ?');
    $stm->execute([$phone_number, $id]);
    if ($stm->fetchColumn() > 0) {
        $_err['phone_number'] = 'Phone number already exists';
    }

    // Validate: email
    if ($email == '') {
        $_err['email'] = 'Required';
    } else if (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    } else if (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    }


    // Validate: name
    if ($name == '') {
        $_err['name'] = 'Required';
    } else if (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Validate: phone_number
    if ($phone_number == '') {
        $_err['phone_number'] = 'Required';
    } else if (strlen($phone_number) > 11) {
        $_err['phone_number'] = 'Maximum 11 characters';
    }

    // Validate: address
    if ($address == '') {
        $_err['address'] = 'Required';
    } elseif (strlen($address) > 100) {
        $_err['address'] = 'Maximum 100 characters';
    }

    // Validate: role
    if ($role == '') {
        $_err['role'] = 'Required';
    }

    // Validate: photo (file) --> optional
    if ($f) {
        if (!str_starts_with($f->type, 'image/')) {
            $_err['photo'] = 'Must be image';
        } else if ($f->size > 1 * 1024 * 1024) {
            $_err['photo'] = 'Maximum 1MB';
        }
    }

    // DB operation
    if (!$_err) {

        // (1) Delete old photo and save new photo (if uploaded)
        if ($f) {
            unlink("../photos/$photo");
            $photo = save_photo($f, '../photos');
        }

        // (2) Update user (email, name, photo)
        $stm = $_db->prepare('
        UPDATE user
        SET email = ?, name = ?, photo = ?, phone_number = ?, address = ?, role = ?
        WHERE id = ?
    ');
    
        $stm->execute([$email, $name, $photo, $phone_number, $address, $role, $id]);



        temp('info', 'Record updated');
        redirect('/../Userlist.php');
    }
}

// ----------------------------------------------------------------------------

$_title = 'User Update';
include '../_head.php';
?>

<p>
    <button data-get="../Userlist.php">⬅️ Back</button>
</p>

<form method="post" class="form" enctype="multipart/form-data">

    <label for="photo">Photo</label>
    <label class="upload" tabindex="0">
        <?= html_file('photo', 'image/*', 'hidden') ?>
        <img src="/../photos/<?= $photo ?>">
    </label>
    <?= err('photo') ?>

    <label for="email">Email</label>
    <?= html_text('email', 'maxlength="100"') ?>
    <?= err('email') ?>

    <label for="name">Name</label>
    <?= html_text('name', 'maxlength="100"') ?>
    <?= err('name') ?>

    <label for="phone_number">Phone Number</label>
    <?= html_text('phone_number', 'maxlength="11"') ?>
    <?= err('phone_number') ?>

    <label for="address">Address</label>
    <?= html_text('address', 'maxlength="100"') ?>
    <?= err('address') ?>

    <label for="role">Role</label>
    <?= html_radios('role', $_role) ?>
    <?= err('role') ?>

    <section>
        <button>Submit</button>
        <button type="reset">Reset</button>
        <a href="password.php">Change Password</a>
    </section>
</form>
<?php

include '../_foot.php';

    </main>

    <footer>
        Developed by <b>MELODIDDY</b> &middot;
        Copyrighted &copy; <?= date('Y') ?>
    </footer>
    </body>

    </html>
<?php
include '_base.php';

// ----------------------------------------------------------------------------

// Admin role
auth('Admin');

//user
$arr = $_db->query('SELECT * FROM user')->fetchAll();
$sort = req('sort', 'asc');
$page = req('page', 1);
$name = req('name');
$role = req('role');

// Use SimplePager for pagination and search
require_once 'lib/SimplePager.php';
$query = 'SELECT * FROM user WHERE name LIKE ?';
$params = ["%$name%"];

if ($role) {
    $query .= ' AND role = ?';
    $params[] = $role;
} else {
    $query = 'SELECT * FROM user WHERE name LIKE ?';
}

$query .= ' ORDER BY role ' . ($sort === 'asc' ? 'ASC' : 'DESC');
$s = new SimplePager($query, $params, 10, $page);
$arr = $s->result;

// ----------------------------------------------------------------------------

$_title = 'Users List ';
include '_head.php';
?>

<style>
    .user-photo {
        width: 120px;
        height: 120px;
        object-fit: cover; /* Ensures the image fits within the dimensions */
    }
</style>

<form style="text-align: center;">
    <?= html_search('name') ?>
    <select name="role">
        <option value="">All Roles</option>
        <option value="Admin" <?= req('role') === 'Admin' ? 'selected' : '' ?>>Admin</option>
        <option value="Member" <?= req('role') === 'Member' ? 'selected' : '' ?>>Member</option>
    </select>
    <button>🔎</button>
</form>

<p style="text-align: center;">
    <button data-get="/userAdmin/insertUser.php">Insert🆕</button>
</p>

<p style="text-align: center;"><?= count($arr) ?> record(s)</p>

<p style="text-align: center;">
    <?= $s->count ?> of <?= $s->item_count ?> record(s) |
    Page <?= $s->page ?> of <?= $s->page_count ?>
</p>

<table class="table">
    <tr>
        <th>No.</th>
        <th>Email</th>
        <th>Name</th>
        <th>Photo</th>
        <th><a href="?sort=<?= $sort === 'asc' ? 'desc' : 'asc' ?>">Role<?= $sort === 'asc' ? '⬆️' : '⬇️' ?></a></th>
        <th></th>
    </tr>

    <?php $counter = ($s->page - 1) * 10 + 1; ?>
    <?php foreach ($arr as $p): ?>
        <tr>
            <td><?= $counter++ ?></td>

            <td><a href="/userAdmin/detailsUser.php?id=<?= $p->id ?>"><?= htmlspecialchars($p->email) ?></a></td>
            <td><a href="/userAdmin/detailsUser.php?id=<?= $p->id ?>"><?= htmlspecialchars($p->name) ?></a></td>
            <td><img src="/photos/<?= $p->photo ?>" class="user-photo"></td>
            <td><?= $p->role ?></td>
            <td>
                <button data-get="/userAdmin/updateUser.php?id=<?= $p->id ?>"> ✏️</button>
                <button data-post="/userAdmin/deleteUser.php?id=<?= $p->id ?>">🗑️</button>
            </td>
        </tr>
    <?php endforeach ?>
</table>

<br>
<?= $s->html() ?>

<?php
include '_foot.php';

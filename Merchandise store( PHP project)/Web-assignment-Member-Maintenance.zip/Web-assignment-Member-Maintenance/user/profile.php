<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// Authenticated users
auth();

if (is_get()) {
    $stm = $_db->prepare('SELECT * FROM user WHERE id = ?');
    $stm->execute([$_user->id]);
    $u = $stm->fetch();

    if (!$u) {
        redirect('/');
    }

    extract((array)$u);
    $_SESSION['photo'] = $u->photo;
}

if (is_post()) {
    $email = req('email');
    $name  = req('name');
    $phone_number = req('phone_number');
    $address = req('address');
    $confirm = req('confirm');
    $photo = $_SESSION['photo'];
    $f = get_file('photo');

    // Validate: email
    if ($email == '') {
        $_err['email'] = 'Required';
    } elseif (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    } elseif (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    } else {
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM user
            WHERE email = ? AND id != ?
        ');
        $stm->execute([$email, $_user->id]);
        if ($stm->fetchColumn() > 0) {
            $_err['email'] = 'Duplicated';
        }
    }

    // Validate: name
    if ($name == '') {
        $_err['name'] = 'Required';
    } elseif (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Validate: phone_number
    if ($phone_number == '') {
        $_err['phone_number'] = 'Required';
    } elseif (strlen($phone_number) > 11) {
        $_err['phone_number'] = 'Maximum 11 characters';
    } else {
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM user
            WHERE phone_number = ? AND id != ?
        ');
        $stm->execute([$phone_number, $_user->id]);
        if ($stm->fetchColumn() > 0) {
            $_err['phone_number'] = 'Duplicated';
        }
    }

    // Validate: address
    if ($address == '') {
        $_err['address'] = 'Required';
    } elseif (strlen($address) > 100) {
        $_err['address'] = 'Maximum 100 characters';
    } else {
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM user
            WHERE address = ? AND id != ?
        ');
        $stm->execute([$address, $_user->id]);
    }

    // Validate: photo (file) --> optional
    if ($f) {
        if (!str_starts_with($f->type, 'image/')) {
            $_err['photo'] = 'Must be image';
        } else if ($f->size > 1 * 1024 * 1024) {
            $_err['photo'] = 'Maximum 1MB';
        }
    }

    // DB operation
    if (!$_err) {

        // (1) Delete old photo and save new photo (if uploaded)
        if ($f) {
            unlink("../photos/$photo");
            $photo = save_photo($f, '../photos');
        }

        // (2) Update user (email, name, photo)
        $stm = $_db->prepare('
        UPDATE user
        SET email = ?, name = ?, photo = ?, phone_number = ?, address = ?
        WHERE id = ?
    ');
        $stm->execute([$email, $name, $photo, $phone_number, $address, $_user->id]);

        // (3) Update session/global user
        $_user->email = $email;
        $_user->name = $name;
        $_user->phone_number = $phone_number;
        $_user->address = $address;
        $_user->photo = $photo;
        $_SESSION['photo'] = $photo;

        temp('info', 'Record updated');
        redirect('/');
    }
}

// ----------------------------------------------------------------------------

$_title = 'Profile';
include '../_head.php';
?>

<form method="post" class="form" enctype="multipart/form-data">

    <label for="photo">Photo</label>
    <label class="upload" tabindex="0">
        <?= html_file('photo', 'image/*', 'hidden') ?>
        <img src="/photos/<?= $photo ?>">
    </label>
    <?= err('photo') ?>

    <label for="email">Email</label>
    <?= html_text('email', 'maxlength="100"') ?>
    <?= err('email') ?>

    <label for="name">Name</label>
    <?= html_text('name', 'maxlength="100"') ?>
    <?= err('name') ?>

    <label for="phone_number">Phone Number</label>
    <?= html_text('phone_number', 'maxlength="11"') ?>
    <?= err('phone_number') ?>

    <label for="address">Address</label>
    <?= html_text('address', 'maxlength="100"') ?>
    <?= err('address') ?>

    <section>
        <button>Update</button>
        <button type="reset">Reset</button>
        <a href="password.php">Change Password</a>
    </section>

    <a href="/logout.php" class="small">Logout</a>

</form>
<?php

include '../_foot.php';

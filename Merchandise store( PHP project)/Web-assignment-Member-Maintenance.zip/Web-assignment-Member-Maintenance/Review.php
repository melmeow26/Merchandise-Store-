<?php

require '_base.php';

// ———– HELPERS ———–
function current_member_id()
{
  return $_SESSION['user']->id ?? null;
}

// handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    $mid = current_member_id() ?: throw new Exception("Login required");
    addReview($_db, $mid, (int)$_POST['rating'], trim($_POST['review']));
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
  } catch (Exception $e) {
    $errors[] = $e->getMessage();
  }
}

// fetch data for display
$avgData    = getAverageRating($_db);
$allReview = getAllReview($_db);
// avoid resubmission


// ———– FETCH AVERAGE & ALL REVIEWs ———–
// average & count
$stm = $_db->prepare("
    SELECT AVG(Rating) AS avg_rating, COUNT(*) AS cnt
    FROM review
");

// execute it
$stm->execute();

// now fetch the one‐row result
$avg = $stm->fetch(PDO::FETCH_ASSOC);

// $avg['avg_rating'] holds the average
// $avg['cnt']        holds the count


// all review (newest first)
$stm = $_db->prepare("
    SELECT 
      r.Rating, 
      r.Comment, 
      u.id, 
      r.RatingId
    FROM review r
    LEFT JOIN user u 
    ON u.id = r.id
    ORDER BY r.RatingId DESC
");
$stm->execute();
$allReview = $stm->fetchAll(PDO::FETCH_ASSOC);

?>

<?php
$_title = 'Shop Reviews';

include '_head.php';
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Shop Reviews</title>
  <style>
    .star {
      color: gold;
      font-size: 1.2em;
    }

    .error {
      color: red;
    }

    .review {
      border-bottom: 1px solid #ccc;
      padding: 8px 0;
    }

    .meta {
      font-size: 0.9em;
      color: #555;
    }
  </style>
</head>

<body>

  <p style="text-align: center;">
    Average Rating:
    <?php
    $avgRating = $avg['avg_rating'] ? round($avg['avg_rating'], 1) : 0;
    for ($i = 1; $i <= 5; $i++) {
      echo $i <= round($avgRating) ? '★' : '☆';
    }
    ?>
    (<?= $avg['cnt'] ?> review<?= $avg['cnt'] != 1 ? 's' : '' ?>)
  </p>

  <h2 style="text-align: center;">Leave Your Review</h2>
  <?php if (!current_member_id()): ?>
    <p style="text-align: center;">You must <a href="/login.php">log in</a> to post a review.</p>
  <?php else: ?>
    <?php if (isset($errors) && $errors): ?>
      <div class="error">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
    <form style="text-align: center;" method="post">
      <label>Rating:
        <select name="rating">
          <?php for ($s = 5; $s >= 1; $s--): ?>
            <option value="<?= $s ?>"><?= $s ?> star<?= $s > 1 ? 's' : '' ?></option>
          <?php endfor; ?>
        </select>
      </label><br><br>
      <label>Review:<br>
        <textarea name="review" rows="4" cols="50" required></textarea>
      </label><br><br>
      <button type="submit">Submit Review</button>
    </form>
  <?php endif; ?>

  <h2 style="text-align: center;">All Reviews</h2>
  <?php if (empty($allReview)): ?>
    <p style="text-align: center;">No reviews yet. Be the first to share your thoughts!</p>
  <?php else: ?>
    <?php foreach ($allReview as $r): ?>
      <div style="text-align: center;" class="review">
        <div class="meta">
          <strong><?= htmlspecialchars($r['username'] ?? 'User#' . $r['id']) ?></strong>
          —
          <?php for ($i = 1; $i <= 5; $i++): ?>
            <?= $i <= $r['Rating'] ? '<span class="star">★</span>' : '☆' ?>
          <?php endfor; ?>
        </div>
        <p><?= nl2br(htmlspecialchars($r['Comment'])) ?></p>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</body>

</html>

<?php

include '_foot.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $_title ?? 'Untitled' ?></title>
    <link rel="shortcut icon" href="/images/animate.jpg">
    <link rel="stylesheet" href="/css/app.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="/js/app.js"></script>
</head>

<body>
    <!-- Flash message -->
    <div id="info"><?= temp('info') ?></div>

    <div class="top-banner">
        ANNOUNCING PARTNERSHIP WITH GLOBAL‑E (04/17/2025)
    </div>

    <header class="header">
        <div class="logo">
            <a href="/"><img src="/images/animate.jpg" alt="Animate International Logo"></a>
        </div>

        <div class="user-section">
            <?php if ($_user): ?>
                <div>
                    <?= $_user->name ?><br>
                    <?= $_user->role ?>
                </div>
                <a href="/user/profile.php"><img src="/photos/<?= $_user->photo ?>" alt="User Photo" style="width:50px; height:50px; border-radius:50%;"></a>
            <?php endif ?>
        </div>
    </header>

    <nav class="nav">
        <a href="/" style="font-weight: bold; color: #d00;">Home</a>

        <a href="/ProductDisplay.php">Product</a>

        <?php if ($_user?->role == 'Admin'): ?>
            <a href="/Productlist.php">Product CRUD</a>
        <?php endif ?>

        <?php if ($_user?->role == 'Admin'): ?>
            <a href="/Userlist.php">Users list</a>
        <?php endif ?>

        <?php if ($_user?->role == 'Admin'): ?>
            <a href="/order/historyAdmin.php">Order History</a>
        <?php endif ?>

        <?php if ($_user?->role == 'Member'): ?>
            <a href="/Order.php">Order</a>
        <?php endif ?>

        <?php if ($_user?->role == 'Member'): ?>
            <a href="/order/history.php">Order History</a>
        <?php endif ?>

        <?php if($_user?->role == 'Member'): ?>
            <a href="/Review.php">Rating Us</a>  
        <?php endif ?>

        <div></div>

        <?php if ($_user): ?>
            <a href="/logout.php">Logout</a>
        <?php else: ?>
            <a href="/login.php">Login</a>
        <?php endif ?>
    </nav>

    <main>
        <h1><?= $_title ?? 'Untitled' ?></h1>
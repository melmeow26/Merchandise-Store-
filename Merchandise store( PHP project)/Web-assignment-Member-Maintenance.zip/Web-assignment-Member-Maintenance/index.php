<?php
require '_base.php';
//-----------------------------------------------------------------------------

// Get list of uploaded and make it best seller
$arr = glob('uploads/*.jpg');
$arr = array_map('basename', $arr);
$bestSellers = array_slice($arr, 0, 5); // Show only the first 4

// ----------------------------------------------------------------------------
$_title = 'Welcome To Animate ';
include '_head.php';
?>

<banner>
    <div class="banner-slider">
        <div class="slide active">
            <img src="images/Obey_Me!popup.jpg" alt="Obey Me! Nightbringer Pop-Up Store banner">
        </div>
        <div class="slide">
            <img src="images/VsingerXartistCollab.jpg" alt="Vsinger X Artist Collaboration banner">
        </div>
        <div class="slide">
            <img src="images/iDoLish7.jpg" alt="IDOLiSH7 banner">
        </div>
    </div>
</banner>

<!-- Best Seller Section -->
<h2 class="section-title">Top 5 Best Sellers</h2>


<div class="best-seller-row">
    <?php foreach ($bestSellers as $f): ?>
        <div class="product-item">
            <img src="/uploads/<?= $f ?>" alt="Top 5 Best Seller">
        </div>
    <?php endforeach ?>
    <!-- See More Image (appears beside the last product) -->
    <div class="see-more-item">
        <?php if ($_user): ?>
            <a href="Order.php">
                <img src="images/see_more.jpg" alt="See More" class="see-more-image">
            </a>
        <?php else: ?>
            <a href="ProductDisplay.php">
                <img src="images/see_more.jpg" alt="See More" class="see-more-image">
            </a>
        <?php endif ?>
    </div>
</div>

<?php
include '_foot.php';

<?php
require '_base.php';

// ----------------------------------------------------------------------------
// Member role check
auth();

// Setup
$name       = req('name');
$page       = (int)req('page') ?: 1;
$category   = req('category') ?? '';
$min_price  = req('min_price') ? (float)req('min_price') : 0;
$max_price  = req('max_price') ? (float)req('max_price') : 10000;
$products_per_page = 5;
$start      = ($page - 1) * $products_per_page;

$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;


$array_display = [];
$total = 0;

// Fetch distinct categories for dropdown
$categoryStmt = $_db->prepare("SELECT DISTINCT category FROM product");
$categoryStmt->execute();
$categoryResult = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

if (isset($user)) {
    // Build dynamic query
    $sql = "SELECT * FROM product WHERE price BETWEEN :min_price AND :max_price";
    $count_sql = "SELECT COUNT(*) FROM product WHERE price BETWEEN :min_price AND :max_price";
    $params = [
        ':min_price' => $min_price,
        ':max_price' => $max_price
    ];

    if (!empty($category)) {
        $sql .= " AND category = :category";
        $count_sql .= " AND category = :category";
        $params[':category'] = $category;
    }

    if (!empty($name)) {
        $sql .= " AND name LIKE :name";
        $count_sql .= " AND name LIKE :name";
        $params[':name'] = "%$name%";
    }

    $sql .= " LIMIT :start, :limit";

    $productStmt = $_db->prepare($sql);
    foreach ($params as $key => $val) {
        $productStmt->bindValue($key, $val);
    }
    $productStmt->bindValue(':start', $start, PDO::PARAM_INT);
    $productStmt->bindValue(':limit', $products_per_page, PDO::PARAM_INT);
    $productStmt->execute();
    $products = $productStmt->fetchAll(PDO::FETCH_ASSOC);

    $countStmt = $_db->prepare($count_sql);
    foreach ($params as $key => $val) {
        $countStmt->bindValue($key, $val);
    }
    $countStmt->execute();
    $total = $countStmt->fetchColumn();

    foreach ($products as $product) {
        $array_display[$product['id']] = [
            'name'  => $product['name'],
            'photo' => $product['photo']
        ];
    }

    $number_of_pages = ceil($total / $products_per_page);
} else {
    $guest_images = glob('uploads/*.jpg');
    $guest_images = array_map('basename', $guest_images);
}

// ----------------------------------------------------------------------------
$_title = 'Product Display';
include '_head.php';
?>

<!-- 🔍 Search and Filter Form -->
<h2 style="text-align: center;">Filter Products</h2>
<form style="text-align: center;" method="GET" action="">
    <label>Category:</label>
    <select name="category">
        <option value="">All</option>
        <?php foreach ($categoryResult as $row): ?>
            <option value="<?= htmlspecialchars($row['category']) ?>" <?= ($category == $row['category']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($row['category']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Min Price:</label>
    <input type="number" name="min_price" value="<?= htmlspecialchars($min_price) ?>" step="0.01">

    <label>Max Price:</label>
    <input type="number" name="max_price" value="<?= htmlspecialchars($max_price) ?>" step="0.01">

    <label>Product Name:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($name) ?>">

    <button type="submit">🔍 Filter</button>
    <!-- Clear Filters Link -->
    <a href="ProductDisplay.php" style="margin-left:10px;">🔄 Clear Filters</a>
</form>

<?php if ($_user?->role !== 'Admin'): ?>
    <?php if ($_user?->role == 'Member'): ?>
        <h2 style="text-align: center;">Click <a href="Order.php">Order</a> to order.</h2>
    <?php else: ?>
        <h2 style="text-align: center;">Please <a href="login.php">Login</a> first to Order.</h2>
    <?php endif ?>
<?php endif ?>

<!-- 📸 Photo Count -->
<p style="text-align: center;"><?= isset($user) ? count($array_display) : count($guest_images) ?> photo(s)</p>

<!-- 🖼️ Product / Guest Image Display -->
<div class="photos">
    <?php if (isset($user)): ?>
        <?php foreach ($array_display as $id => $product): ?>
            <div>
                <a href="/product/detailUser.php?id=<?= $id ?>" class="href-product">
                    <img src="/uploads/<?= htmlspecialchars($product['photo']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <p><?= htmlspecialchars($product['name']) ?></p>
                </a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <?php foreach ($guest_images as $img): ?>
            <div>
                <img src="/uploads/<?= htmlspecialchars($img) ?>" alt="Guest Image">
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- 📄 Pagination -->
<?php if (isset($user) && $number_of_pages > 1): ?>
    <div class="paging">
        <?php for ($i = 1; $i <= $number_of_pages; $i++): ?>
            <a href="?page=<?= $i ?>&name=<?= urlencode($name) ?>&category=<?= urlencode($category) ?>&min_price=<?= $min_price ?>&max_price=<?= $max_price ?>">
                <?= $i ?>
            </a>
        <?php endfor ?>
    </div>
<?php endif; ?>

<!-- 💅 Styles -->
<style>
    .photosform {
        position: absolute;
        background: #0009;
        color: #fff;
        padding: 5px;
        text-align: center;
    }

    .photos {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
    }

    .photos div {
        width: 150px;
        text-align: center;
    }

    .photos img {
        max-width: 100%;
        height: auto;
        display: block;
    }

    .paging a {
        margin: 0 5px;
        text-decoration: none;
        font-weight: bold;
    }
</style>

<?php include '_foot.php'; ?>

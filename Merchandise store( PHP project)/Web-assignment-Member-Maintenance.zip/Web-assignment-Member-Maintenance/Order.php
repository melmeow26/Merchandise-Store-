<?php
require '_base.php';

// ----------------------------------------------------------------------------

// Member role
auth('Member');

$name = req('name');

// search
$stm = $_db->prepare('SELECT * FROM product WHERE name LIKE?');
$stm->execute(["%$name%"]);
$arr = $stm->fetchAll();

if (is_post()) {
    $id   = req('id');
    $unit = req('unit');
    update_cart($id, $unit);
    // redirect();
}

// ----------------------------------------------------------------------------

$_title = 'Order';
include '_head.php';
?>

<style>
    .photosform {
        position: absolute;
        background: #0009;
        color: #fff;
        padding: 5px;
        text-align: center;
    }
</style>

<form style="text-align: center;">
    <?= html_search('name') ?>
    <button>🔍</button>
    <a class="icon" href="/order/cart.php">View Cart🛒
        <?php
        $cart = get_cart();
        $count = count($cart);
        if ($count) echo "($count)";
        ?>
    </a>
</form>

<?php
// Handle filter input
$category = isset($_GET['category']) ? $_GET['category'] : '';
$min_price = isset($_GET['min_price']) ? (float)$_GET['min_price'] : 0;
$max_price = isset($_GET['max_price']) ? (float)$_GET['max_price'] : 10000;

// Fetch distinct categories for dropdown
$categoryStmt = $_db->prepare("SELECT DISTINCT category FROM product");
$categoryStmt->execute();
$categoryResult = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
// Build product query
$sql = "SELECT * FROM product WHERE price BETWEEN :min_price AND :max_price";
$params = [
    ':min_price' => $min_price,
    ':max_price' => $max_price
];

if (!empty($category)) {
    $sql .= " AND category = :category";
    $params[':category'] = $category;
}
if (!empty($name)) {
    $sql .= " AND name LIKE :name";
    $params[':name'] = "%$name%";
}
$productStmt = $_db->prepare($sql);
$productStmt->execute($params);
$productResult = $productStmt->fetchAll();
?>

<html>

<head>
    <title>Product Filtering</title>
</head>

<body>
    <h2 style="text-align: center;">Filter Products</h2>
    <form style="text-align: center;" method="GET" action="">
        <label>Category:</label>
        <select name="category">
            <option value="">All</option>
            <?php foreach ($categoryResult as $row): ?>
                <option value="<?= htmlspecialchars($row['category']) ?>" <?= ($category == $row['category']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($row['category']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Min Price:</label>
        <input type="number" name="min_price" value="<?= htmlspecialchars($min_price) ?>" step="0.01">

        <label>Max Price:</label>
        <input type="number" name="max_price" value="<?= htmlspecialchars($max_price) ?>" step="0.01">

        <button type="submit">Filter</button>
        <a href="Order.php" style="margin-left:10px;">🔄 Clear Filters</a>
    </form>

</body>

</html>

<p style="text-align: center;"><?= count($productResult) ?> record(s)</p>

<h2 style="text-align: center;">Please select quantity first to add to cart. </h2>

<?php if (count($productResult) === 0): ?>
    <h1>No Result</h1>
<?php else: ?>
    <div class="photos">
        <?php foreach ($productResult as $p): ?>
            <?php
            $cart = get_cart();
            $id   = $p->id;
            $unit = $cart[$p->id] ?? 0;
            ?>
            <div class="product">
                <img src="/uploads/<?= $p->photo ?>"
                    data-get="/product/detail.php?id=<?= $p->id ?>">
                    <div><?= htmlspecialchars($p->name) ?>  <span class="product-price">RM <?= htmlspecialchars($p->price) ?></span></div>
                    <button id="add_cart" data-id=<?= $p->id ?>>Add to Cart</button>

                <form id="cart_form_<?= $p->id ?>" method="post">
                    <?= $unit ? '✅' : '' ?>
                    <?= html_hidden('id') ?>
                    <?= html_select('unit', $_units, '') ?>
                </form>
            </div>
        <?php endforeach ?>
    </div>
<?php endif; ?>

<script>
    // $('select').on('change', e => e.target.form.submit());
    $(document).on('click', '#add_cart', function(e) {
        const id = $(this).data('id');
        e.preventDefault();
        const form = $(`#cart_form_${id}`);
        form.submit();
    });
</script>

<?php
include '_foot.php';

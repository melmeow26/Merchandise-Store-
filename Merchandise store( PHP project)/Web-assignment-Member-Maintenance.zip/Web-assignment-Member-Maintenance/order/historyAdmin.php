<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// (1) Authorization (Admin only)
auth('Admin');

// (2) Get all orders with user names (descending)
$stm = $_db->prepare('
    SELECT o.*, u.name AS user_name
    FROM `order` AS o
    JOIN `user` AS u ON o.user_id = u.id
    ORDER BY o.id DESC
');
$stm->execute();
$arr = $stm->fetchAll();

// ----------------------------------------------------------------------------

$_title = 'Admin Order Listing';
include '../_head.php';
?>

<!-- (B) EXTRA: CSS -->
<style>
    tr:hover .popup {
        display: grid !important;
        grid: auto / repeat(5, auto);
        gap: 1px;
        border: none;
    }

    .popup img {
        width: 50px;
        height: 50px;
        outline: 1px solid #333;
    }
</style>

<p style="text-align: center;"><?= count($arr) ?> order(s) found</p>

<table class="table">
    <tr>
        <th>Order ID</th>
        <th>User</th>
        <th>Datetime</th>
        <th>Count</th>
        <th>Total (RM)</th>
        <th></th>
    </tr>

    <?php foreach ($arr as $o): ?>
    <tr>
        <td><?= $o->id ?></td>
        <td><?= htmlspecialchars($o->user_name) ?></td>
        <td><?= $o->datetime ?></td>
        <td class="right"><?= $o->count ?></td>
        <td class="right"><?= $o->total ?></td>
        <td>
            <button data-get="order_detailAdmin.php?id=<?= $o->id ?>">Detail</button>
            <!-- (A) EXTRA: Product photos -->
            <div class="popup">
                <?php
                    $stm = $_db->prepare('
                        SELECT p.photo 
                        FROM item AS i
                        JOIN product AS p ON i.product_id = p.id
                        WHERE i.order_id = ?
                    ');
                    $stm->execute([$o->id]);
                    $photos = $stm->fetchAll(PDO::FETCH_COLUMN);
                    foreach ($photos as $photo) {
                        echo "<img src='/uploads/" . htmlspecialchars($photo) . "'>";
                    }
                ?>
            </div>
        </td>
    </tr>
    <?php endforeach ?>
</table>

<?php
include '../_foot.php';
?>

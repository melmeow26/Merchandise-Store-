<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// (1) Authorization (member)
auth('Admin');

// (2) Return order (based on id) belong to the user
$id = req('id');
$stm = $_db->prepare('
    SELECT o.*, u.name AS user_name, u.phone_number, u.address
    FROM `order` AS o
    JOIN `user` AS u ON o.user_id = u.id
    WHERE o.id = ?
    ORDER BY o.id DESC
');
$stm->execute([$id]);
$o = $stm->fetch();
$stm->execute();
$o = $stm->fetch();
if (!$o) redirect('historyAdmin.php');

// (3) Return items (and products) belong to the order
$stm = $_db->prepare('
    SELECT i.*, p.name, p.photo
    FROM item AS i, product AS p
    WHERE i.product_id = p.id
    AND i.order_id = ?
');
$stm->execute([$id]);
$items = $stm->fetchAll();

// ----------------------------------------------------------------------------

$_title = 'Order Detail';
include '../_head.php';
?>

<style>
    .order-photo {
        width: 120px;
        height: 120px;
        object-fit: cover; /* Ensures the image fits within the dimensions */
    }
</style>

<div class="order-detail-page">
<div class="order-header">
    <h2>Order #<?= htmlspecialchars($o->id) ?></h2>
    <div class="info-section">
        <div>
            <h4>Order Details</h4>
            <p><strong>Date:</strong> <?= htmlspecialchars($o->datetime) ?></p>
            <p><strong>Items:</strong> <?= htmlspecialchars($o->count) ?></p>
            <p><strong>Payment Method:</strong> <?= htmlspecialchars($o->payment_method, 2) ?></p>
            <p><strong>Total:</strong> RM <?= number_format($o->total, 2) ?></p>
        </div>
        <div>
            <h4>Delivery Information</h4>
            <p><strong>Phone:</strong> <?= htmlspecialchars($o->phone_number) ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($o->address) ?></p>
            <p><strong>Payment Status:</strong> 
            <span style="color: green; font-weight: bold;">Successful</span>
        </div>
    </div>
</div>

<h3>Ordered Items (<?= count($items) ?>)</h3>

<table class="table">
    <tr>
        <th>Product Id</th>
        <th>Product Name</th>
        <th>Photo</th>
        <th>Price (RM)</th>
        <th>Unit</th>
        <th>Subtotal (RM)</th>
    </tr>

    <?php foreach ($items as $i): ?>
    <tr>
        <td><?= $i->product_id ?></td>
        <td><?= $i->name ?></td>
        <td><img src="/uploads/<?= $i->photo ?>" class="order-photo"></td>
        <td class="right"><?= $i->price ?></td>
        <td class="right"><?= $i->unit ?></td>
        <td class="right">
            <?= $i->subtotal ?>
        </td>
    </tr>
    <?php endforeach ?>

    <tr>
        <th colspan="4"></th>
        <th class="right"><?= $o->count ?></th>
        <th class="right"><?= $o->total ?></th>
    </tr>
</table>

<div class="form-footer">
<button data-get="/index.php">Back to Home</button>
</div>

<?php
include '../_foot.php';
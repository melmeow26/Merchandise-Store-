<?php
include '../_base.php';


// ----------------------------------------------------------------------------

// (1) Authorization (member)
auth('Member');

// (2) Get shopping cart (reject if empty)
$cart = get_cart();
if (!$cart) redirect('cart.php');

// Handle POST request (when payment method is selected)
if (is_post()) {
    $method = req('method');
    $name = req('name');
    $card = req('card');
    $expiry = req('expiry');
    $cvv = req('cvv');

    if (!in_array($method, ['credit_card', 'debit_card', 'touch_n_go'])) {
        temp('err', 'Invalid payment method.');
        redirect();
    }

    if (in_array($method, ['credit_card', 'debit_card'])) {
        if (!$name || !$card || !$expiry || !$cvv) {
            temp('err', 'Name, card number, expiry date, and CVV are required.');
            redirect();
        }

        // Cardholder name validation (only letters and spaces)
        if (!preg_match('/^[A-Za-z ]+$/', $name)) {
            temp('err', 'Cardholder name must contain only letters and spaces.');
            redirect();
        }

        // Card number validation (16 digits)
        $card_number = str_replace(' ', '', $card); // remove spaces
        if (!preg_match('/^\d{16}$/', $card_number)) {
            temp('err', 'Card number must be 16 digits.');
            redirect();
        }

        // Expiry date validation (MM/YY and not expired)
        if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry)) {
            temp('err', 'Expiry date must be in MM/YY format.');
            redirect();
        } else {
            [$month, $year] = explode('/', $expiry);
            $currentYear = date('y');
            $currentMonth = date('m');

            if ($year < $currentYear || ($year == $currentYear && $month < $currentMonth)) {
                temp('err', 'Card is expired.');
                redirect();
            }
        }

        // CVV validation (3 digits)
        if (!preg_match('/^\d{3}$/', $cvv)) {
            temp('err', 'CVV must be 3 digits.');
            redirect();
        }
    }

    // ------------------------------------------
    // DB transaction (insert order and items)
    // ------------------------------------------

    // (A) Begin transaction
    $_db->beginTransaction();

    // (B) Insert order, keep order id
    $stm = $_db->prepare('
        INSERT INTO `order` (datetime, user_id, payment_method)
        VALUES (NOW(), ?, ?)
    ');
    $stm->execute([$_user->id, $method]);
    $id = $_db->lastInsertId();

    // (C) Insert items
    $stm = $_db->prepare('
        INSERT INTO item (order_id, product_id, price, unit, subtotal)
        VALUES (?, ?, (SELECT price FROM product WHERE id = ?), ?, price * unit)
    ');
    foreach ($cart as $product_id => $unit) {
        $stm->execute([$id, $product_id, $product_id, $unit]);
    }

    // (D) Update order (count and total)
    $stm = $_db->prepare('
        UPDATE `order`
        SET count = (SELECT SUM(unit) FROM item WHERE order_id = ?),
            total = (SELECT SUM(subtotal) FROM item WHERE order_id = ?)
        WHERE id = ?
    ');
    $stm->execute([$id, $id, $id]);

    // (E) Commit transaction
    $_db->commit();

    // ------------------------------------------

    // (3) Clear shopping cart
    set_cart();

    // (4) Redirect to order detail
    temp('info', 'Payment successful! Order placed.');
    redirect("order_detail.php?id=$id");
}

// ----------------------------------------------------------------------------

$_title = 'Payment';
include '../_head.php';
?>

<style>
    .payment-methods {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 20px;
    }

    .payment-options {
        display: flex;
        justify-content: center;
        gap: 30px;
        /* Space between payment options */
    }

    .payment-option {
        display: flex;
        flex-direction: column;
        align-items: center;
        cursor: pointer;
        text-align: center;
    }

    .payment-option img {
        width: 100px;
        /* Adjust size of payment icons */
        height: auto;
        margin-bottom: 10px;
        border: 2px solid transparent;
        border-radius: 8px;
        transition: border-color 0.3s ease;
    }

    .payment-option:hover img {
        border-color: #007bff;
        /* Highlight on hover */
    }

    #card-details,
    #qr-code {
        border: 1px solid #ccc;
        padding: 20px;
        border-radius: 8px;
        background-color: #f9f9f9;
        width: 300px;
    }
</style>
<h2 style="text-align: center;">Select Payment Method</h2>

<?php if ($msg = temp('err')): ?>
    <p class="err"><?= encode($msg) ?></p>
<?php endif ?>

<form method="post" style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 100px;">
    <div class="payment-methods">
        <div class="payment-options">
            <?php
            $methods = [
                'credit_card' => 'credit.png',
                'debit_card'  => 'debit.png',
                'touch_n_go'  => 'tng.png',
            ];

            foreach ($methods as $value => $img) {
                echo "
                        <label class='payment-option' onclick=\"selectPaymentMethod('$value')\">
                            <input type='radio' name='method' value='$value' required style='display: none;'>
                            <img src='/images/$img' alt='$value'>
                            <div>" . ucfirst(str_replace('_', ' ', $value)) . "</div>
                        </label>
                    ";
            }
            ?>
        </div>

        <!-- Card Details Section -->
        <div id="card-details" style="display: none; text-align: center; margin-top: 20px;">
            <div>
                <label for="name">Cardholder Name:</label>
                <input type="text" id="name" name="name">
            </div>
            <div style="margin-top: 10px;">
                <label for="card">Card Number:</label>
                <input type="text" id="card" name="card" placeholder="1234 5678 9012 3456">
            </div>
            <div style="margin-top: 10px;">
                <label for="expiry">Expiry Date:</label>
                <input type="text" id="expiry" name="expiry" placeholder="MM/YY">
            </div>
            <div style="margin-top: 10px;">
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" placeholder="123">
            </div>
        </div>

        <!-- QR Code Section -->
        <div id="qr-code" style="display: none; text-align: center; margin-top: 20px;">
            <h4>Scan this QR to Pay</h4>
            <img src="/images/scam.png" alt="Touch n Go QR Code" style="max-width: 200px;">
        </div>
    </div>

    <div style="text-align: center; margin-top: 30px;">
        <button data-get="cart.php" style="margin-right: 10px;">⬅️ back</button>
        <button type="submit" class="btn btn-primary">Complete Payment</button>
    </div>
</form>

<script>
    function selectPaymentMethod(method) {
        // Hide all sections initially
        document.getElementById('card-details').style.display = 'none';
        document.getElementById('qr-code').style.display = 'none';

        // Show the relevant section based on the selected method
        if (method === 'credit_card' || method === 'debit_card') {
            document.getElementById('card-details').style.display = 'block';
        } else if (method === 'touch_n_go') {
            document.getElementById('qr-code').style.display = 'block';
        }
    }
</script>

<?php
include '../_foot.php';

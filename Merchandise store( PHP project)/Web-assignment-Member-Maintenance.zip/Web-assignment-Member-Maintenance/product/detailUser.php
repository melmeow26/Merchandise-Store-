<?php
include '../_base.php';

// ----------------------------------------------------------------------------

if (is_post()) {
    $id   = req('id');
    redirect();
}

$id  = req('id');
$stm = $_db->prepare('SELECT * FROM product WHERE id = ?');
$stm->execute([$id]);
$p = $stm->fetch();
if (!$p) redirect('../ProductDisplay.php');

// ----------------------------------------------------------------------------

$_title = 'Product Details';
include '../_head.php';
?>

<style>
    #photo {
        display: block;
        border: 1px solid #333;
        width: 200px;
        height: 200px;
    }
</style>

<div style="display: flex; justify-content: center; align-items: center; height: auto;">
    <img src="/../uploads/<?= $p->photo ?>" id="photo">
</div>

<table class="table detail">
    <tr>
        <th>Id</th>
        <td><?= $p->id ?></td>
    </tr>
    <tr>
        <th>Name</th>
        <td><?= $p->name ?></td>
    </tr>
    <tr>
        <th>Price</th>
        <td>RM <?= $p->price ?></td>
    </tr>

    <tr>
        <th>Description</th>
        <td><?= $p->description ?? 'No description available.' ?></td>  
    </tr>
</table>

<p>
    <button data-get="../ProductDisplay.php">⬅️ back</button>
</p>

<script>
    $('select').on('change', e => e.target.form.submit());
</script>

<?php
include '../_foot.php';
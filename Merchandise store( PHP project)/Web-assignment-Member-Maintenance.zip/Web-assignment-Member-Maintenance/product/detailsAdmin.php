<?php
require '../_base.php';

// Get the product ID from the query string
$id = req('id');

// Fetch product details from the database
$stm = $_db->prepare('SELECT * FROM product WHERE id = ?');
$stm->execute([$id]);
$product = $stm->fetch(PDO::FETCH_OBJ);

if (!$product) {
    die('Product not found.');
}

$_title = 'Product Details';
include '../_head.php';
?>

<h1 class="page-title"><?= htmlspecialchars($product->name) ?></h1>

<div class="product-details-container">
    <div class="product-details">
        <img src="/uploads/<?= htmlspecialchars($product->photo) ?>" alt="<?= htmlspecialchars($product->name) ?>" class="product-image">
        <p><strong>Price:</strong> $<?= htmlspecialchars($product->price) ?></p>
        <p><strong>Category:</strong> <?= htmlspecialchars($product->category) ?></p>
        <p><strong>Quantity:</strong> <?= htmlspecialchars($product->quantity) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($product->description ?? 'No description available.') ?></p>
    </div>
</div>

<p>
    <button onclick="history.back()">⬅️ Back</button>
</p>

<?php
include '../_foot.php';

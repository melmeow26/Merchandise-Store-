<?php
require '_base.php';

// ----------------------------------------------------------------------------

// Admin role
auth('Admin');

// ----------------------------------------------------------------------------

$page = req('page', 1);
$name = req('name');
$category = req('category');
$sort = req('sort', 'asc'); // Default to ascending order

// Validate the sort parameter to prevent SQL injection
if (!in_array($sort, ['asc', 'desc'])) {
    $sort = 'asc';
}

// Use SimplePager for pagination and search
require_once 'lib/SimplePager.php';
$query = 'SELECT * FROM product WHERE name LIKE ?';
$params = ["%$name%"];

if ($category) {
    $query = 'SELECT * FROM product WHERE name LIKE ? AND category = ?';
    $params[] = $category;
} else {
    $query = 'SELECT * FROM product WHERE name LIKE ?';
}

$query .= ' ORDER BY id ' . $sort; // Add sorting


$s = new SimplePager($query, $params, 10, $page);
$arr = $s->result;

// ----------------------------------------------------------------------------

$_title = 'Manage Product';
include '_head.php';
?>

<style>
    .product-photo {
        width: 120px;
        height: 120px;
        object-fit: cover; /* Ensures the image fits within the dimensions */
    }
</style>

<form style="text-align: center;">
    <?= html_search('name') ?>
    <select name="category">
        <option value="">All Categories</option>
        <option value="LND" <?= req('category') === 'LND' ? 'selected' : '' ?>>LND</option>
        <option value="HSR" <?= req('category') === 'HSR' ? 'selected' : '' ?>>HSR</option>
        <option value="HOB" <?= req('category') === 'HOB' ? 'selected' : '' ?>>HOB</option>
        <option value="JJK" <?= req('category') === 'JJK' ? 'selected' : '' ?>>JJK</option>
        <option value="DMS" <?= req('category') === 'DMS' ? 'selected' : '' ?>>DMS</option>

    </select>
    <button>🔎</button>
</form>

<p style="text-align: center;">
    <button data-get="/product/insert.php">Insert🆕</button>
</p>

<p style="text-align: center;"><?= count($arr) ?> record(s)</p>

<p style="text-align: center;">
    <?= $s->count ?> of <?= $s->item_count ?> record(s) |
    Page <?= $s->page ?> of <?= $s->page_count ?>
</p>

<table class="table">
    <tr>
        <th>No.</th>
        <th><a href="?sort=<?= $sort === 'asc' ? 'desc' : 'asc' ?>">Id <?= $sort === 'asc' ? '⬆️' : '⬇️' ?></a>
        </th>
        <th>Name</th>
        <th>Photo</th>
        <th>Price</th>
        <th>Category</th>
        <th>Quantity</th>
        <th></th>
    </tr>

    <?php $counter = ($s->page - 1) * 10 + 1; ?>
    <?php foreach ($arr as $p): ?>
        <tr>
            <td><?= $counter++ ?></td>

            <td><a href="/product/detailsAdmin.php?id=<?= $p->id ?>"><?= $p->id ?></a></td>
            <td><a href="/product/detailsAdmin.php?id=<?= $p->id ?>"><?= htmlspecialchars($p->name) ?></a></td>
            <td><img src="/uploads/<?= $p->photo ?>" class="product-photo"></td>
            <td><?= $p->price ?></td>
            <td><?= $p->category ?></td>
            <td><?= $p->quantity ?></td>

            <td>
                <button data-get="/product/update.php?id=<?= $p->id ?>"> ✏️</button>
                <button data-post="/product/delete.php?id=<?= $p->id ?>">🗑️</button>
            </td>
        </tr>
    <?php endforeach ?>
</table>

<br>

<?= $s->html() ?>

<?php
include '_foot.php';
